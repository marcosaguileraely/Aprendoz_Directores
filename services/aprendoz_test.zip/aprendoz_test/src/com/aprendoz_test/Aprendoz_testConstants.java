
package com.aprendoz_test;



/**
 *  Query names for service "aprendoz_test"
 *  06/13/2012 17:10:52
 * 
 */
public class Aprendoz_testConstants {

    public final static String getInscAlumActividadByIdQueryName = "getInscAlumActividadById";
    public final static String getInformacionValiosaQueryName = "getInformacionValiosa";

    private Aprendoz_testConstants() {
        throw new UnsupportedOperationException();
    }

}
