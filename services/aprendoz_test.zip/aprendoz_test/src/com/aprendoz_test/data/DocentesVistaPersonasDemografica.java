
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaPersonasDemografica
 *  06/12/2012 16:56:27
 * 
 */
public class DocentesVistaPersonasDemografica {

    private DocentesVistaPersonasDemograficaId id;

    public DocentesVistaPersonasDemografica() {
    }

    public DocentesVistaPersonasDemografica(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

    public DocentesVistaPersonasDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

}
