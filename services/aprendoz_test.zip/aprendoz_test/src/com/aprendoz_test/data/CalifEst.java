
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CalifEst
 *  06/12/2012 16:56:27
 * 
 */
public class CalifEst {

    private CalifEstId id;

    public CalifEst() {
    }

    public CalifEst(CalifEstId id) {
        this.id = id;
    }

    public CalifEstId getId() {
        return id;
    }

    public void setId(CalifEstId id) {
        this.id = id;
    }

}
