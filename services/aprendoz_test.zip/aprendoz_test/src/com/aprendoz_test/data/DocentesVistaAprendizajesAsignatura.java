
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAprendizajesAsignatura
 *  06/12/2012 16:56:27
 * 
 */
public class DocentesVistaAprendizajesAsignatura {

    private DocentesVistaAprendizajesAsignaturaId id;

    public DocentesVistaAprendizajesAsignatura() {
    }

    public DocentesVistaAprendizajesAsignatura(DocentesVistaAprendizajesAsignaturaId id) {
        this.id = id;
    }

    public DocentesVistaAprendizajesAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesVistaAprendizajesAsignaturaId id) {
        this.id = id;
    }

}
