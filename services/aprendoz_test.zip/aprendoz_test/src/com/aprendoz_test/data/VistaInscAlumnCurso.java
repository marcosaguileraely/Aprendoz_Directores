
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaInscAlumnCurso
 *  06/12/2012 16:56:27
 * 
 */
public class VistaInscAlumnCurso {

    private VistaInscAlumnCursoId id;

    public VistaInscAlumnCurso() {
    }

    public VistaInscAlumnCurso(VistaInscAlumnCursoId id) {
        this.id = id;
    }

    public VistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(VistaInscAlumnCursoId id) {
        this.id = id;
    }

}
