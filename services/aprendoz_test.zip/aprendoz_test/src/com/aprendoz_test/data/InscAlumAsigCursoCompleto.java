
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscAlumAsigCursoCompleto
 *  06/12/2012 16:56:27
 * 
 */
public class InscAlumAsigCursoCompleto {

    private InscAlumAsigCursoCompletoId id;

    public InscAlumAsigCursoCompleto() {
    }

    public InscAlumAsigCursoCompleto(InscAlumAsigCursoCompletoId id) {
        this.id = id;
    }

    public InscAlumAsigCursoCompletoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoCompletoId id) {
        this.id = id;
    }

}
