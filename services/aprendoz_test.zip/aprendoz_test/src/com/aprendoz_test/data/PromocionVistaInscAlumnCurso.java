
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PromocionVistaInscAlumnCurso
 *  06/12/2012 16:56:27
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCurso() {
    }

    public PromocionVistaInscAlumnCurso(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
