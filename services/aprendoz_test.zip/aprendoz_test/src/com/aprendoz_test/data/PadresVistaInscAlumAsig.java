
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaInscAlumAsig
 *  06/12/2012 16:56:27
 * 
 */
public class PadresVistaInscAlumAsig {

    private PadresVistaInscAlumAsigId id;

    public PadresVistaInscAlumAsig() {
    }

    public PadresVistaInscAlumAsig(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

    public PadresVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

}
