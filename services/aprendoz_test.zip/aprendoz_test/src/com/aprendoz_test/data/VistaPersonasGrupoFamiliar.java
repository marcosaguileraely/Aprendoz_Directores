
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaPersonasGrupoFamiliar
 *  06/12/2012 16:56:27
 * 
 */
public class VistaPersonasGrupoFamiliar {

    private VistaPersonasGrupoFamiliarId id;

    public VistaPersonasGrupoFamiliar() {
    }

    public VistaPersonasGrupoFamiliar(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

    public VistaPersonasGrupoFamiliarId getId() {
        return id;
    }

    public void setId(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

}
