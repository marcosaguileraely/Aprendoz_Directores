
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscipcionesVistaAsignaturas
 *  06/12/2012 16:56:27
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturas() {
    }

    public InscipcionesVistaAsignaturas(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}
