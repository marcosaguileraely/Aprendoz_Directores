
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaCalificacionFinal
 *  06/12/2012 16:56:27
 * 
 */
public class DocentesVistaCalificacionFinal {

    private DocentesVistaCalificacionFinalId id;

    public DocentesVistaCalificacionFinal() {
    }

    public DocentesVistaCalificacionFinal(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

    public DocentesVistaCalificacionFinalId getId() {
        return id;
    }

    public void setId(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

}
