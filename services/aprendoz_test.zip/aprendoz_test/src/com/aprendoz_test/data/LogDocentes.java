
package com.aprendoz_test.data;

import java.util.Date;


/**
 *  aprendoz_test.LogDocentes
 *  06/12/2012 16:56:27
 * 
 */
public class LogDocentes {

    private LogDocentesId id;
    private Date fechaIngreso;
    private Date horaIngreso;

    public LogDocentes() {
    }

    public LogDocentes(Date fechaIngreso, Date horaIngreso) {
        this.fechaIngreso = fechaIngreso;
        this.horaIngreso = horaIngreso;
    }

    public LogDocentes(LogDocentesId id, Date fechaIngreso, Date horaIngreso) {
        this.id = id;
        this.fechaIngreso = fechaIngreso;
        this.horaIngreso = horaIngreso;
    }

    public LogDocentesId getId() {
        return id;
    }

    public void setId(LogDocentesId id) {
        this.id = id;
    }

    public Date getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public Date getHoraIngreso() {
        return horaIngreso;
    }

    public void setHoraIngreso(Date horaIngreso) {
        this.horaIngreso = horaIngreso;
    }

}
