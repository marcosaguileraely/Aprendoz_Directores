
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaActividades
 *  06/12/2012 16:56:27
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividades() {
    }

    public PadresVistaActividades(PadresVistaActividadesId id) {
        this.id = id;
    }

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}
