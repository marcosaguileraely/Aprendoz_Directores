
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AprLogrados
 *  06/12/2012 16:56:27
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogrados() {
    }

    public AprLogrados(AprLogradosId id) {
        this.id = id;
    }

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
