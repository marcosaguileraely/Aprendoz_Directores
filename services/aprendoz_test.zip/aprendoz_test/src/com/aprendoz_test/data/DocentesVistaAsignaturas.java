
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAsignaturas
 *  06/12/2012 16:56:27
 * 
 */
public class DocentesVistaAsignaturas {

    private DocentesVistaAsignaturasId id;

    public DocentesVistaAsignaturas() {
    }

    public DocentesVistaAsignaturas(DocentesVistaAsignaturasId id) {
        this.id = id;
    }

    public DocentesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturasId id) {
        this.id = id;
    }

}
