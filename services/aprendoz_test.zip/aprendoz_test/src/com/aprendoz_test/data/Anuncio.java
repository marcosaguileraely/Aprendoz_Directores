
package com.aprendoz_test.data;



/**
 *  aprendoz_test.Anuncio
 *  06/12/2012 16:56:27
 * 
 */
public class Anuncio {

    private String anuncio;

    public Anuncio() {
    }

    public Anuncio(String anuncio) {
        this.anuncio = anuncio;
    }

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
