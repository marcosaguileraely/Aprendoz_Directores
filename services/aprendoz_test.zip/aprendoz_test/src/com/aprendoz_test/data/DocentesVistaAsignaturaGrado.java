
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAsignaturaGrado
 *  06/12/2012 16:56:27
 * 
 */
public class DocentesVistaAsignaturaGrado {

    private DocentesVistaAsignaturaGradoId id;

    public DocentesVistaAsignaturaGrado() {
    }

    public DocentesVistaAsignaturaGrado(DocentesVistaAsignaturaGradoId id) {
        this.id = id;
    }

    public DocentesVistaAsignaturaGradoId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturaGradoId id) {
        this.id = id;
    }

}
