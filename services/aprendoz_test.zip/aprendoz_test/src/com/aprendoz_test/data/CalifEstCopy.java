
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CalifEstCopy
 *  06/12/2012 16:56:27
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopy() {
    }

    public CalifEstCopy(CalifEstCopyId id) {
        this.id = id;
    }

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
