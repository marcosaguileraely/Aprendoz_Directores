
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VProfesorAsignatura
 *  06/12/2012 16:56:27
 * 
 */
public class VProfesorAsignatura {

    private VProfesorAsignaturaId id;

    public VProfesorAsignatura() {
    }

    public VProfesorAsignatura(VProfesorAsignaturaId id) {
        this.id = id;
    }

    public VProfesorAsignaturaId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaId id) {
        this.id = id;
    }

}
