
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VProfesorAsignaturaCompleto
 *  06/12/2012 16:56:27
 * 
 */
public class VProfesorAsignaturaCompleto {

    private VProfesorAsignaturaCompletoId id;

    public VProfesorAsignaturaCompleto() {
    }

    public VProfesorAsignaturaCompleto(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

    public VProfesorAsignaturaCompletoId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

}
