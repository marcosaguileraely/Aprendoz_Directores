
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaRecursos
 *  06/12/2012 16:56:27
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursos() {
    }

    public PadresVistaRecursos(PadresVistaRecursosId id) {
        this.id = id;
    }

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
