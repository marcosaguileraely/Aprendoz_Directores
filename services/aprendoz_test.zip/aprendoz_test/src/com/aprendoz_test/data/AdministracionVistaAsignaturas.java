
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaAsignaturas
 *  06/12/2012 16:56:27
 * 
 */
public class AdministracionVistaAsignaturas {

    private AdministracionVistaAsignaturasId id;

    public AdministracionVistaAsignaturas() {
    }

    public AdministracionVistaAsignaturas(AdministracionVistaAsignaturasId id) {
        this.id = id;
    }

    public AdministracionVistaAsignaturasId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasId id) {
        this.id = id;
    }

}
