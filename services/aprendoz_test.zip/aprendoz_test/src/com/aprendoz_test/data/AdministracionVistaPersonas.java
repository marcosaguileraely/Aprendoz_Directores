
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaPersonas
 *  06/12/2012 16:56:27
 * 
 */
public class AdministracionVistaPersonas {

    private AdministracionVistaPersonasId id;

    public AdministracionVistaPersonas() {
    }

    public AdministracionVistaPersonas(AdministracionVistaPersonasId id) {
        this.id = id;
    }

    public AdministracionVistaPersonasId getId() {
        return id;
    }

    public void setId(AdministracionVistaPersonasId id) {
        this.id = id;
    }

}
